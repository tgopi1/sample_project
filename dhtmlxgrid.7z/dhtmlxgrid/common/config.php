<?php
/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
This version of Software is free for using in non-commercial applications.
For commercial use please contact sales@dhtmlx.com to obtain license
*/

    $mysql_host = "db2.dhtmlx.com";
    $mysql_user = "dhtmuzer_ro";
    $mysql_pasw = "gp45_gm";
    $mysql_db   = "dhtmlxsamples";

?>
