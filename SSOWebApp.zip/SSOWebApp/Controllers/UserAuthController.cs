﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.DirectoryServices;
namespace SSOWebApp.Controllers
{
    public class UserAuthController : Controller
    {
        // GET: UserAuth
        public ActionResult Index()
        {
            return View();
        }
        public int ValidateUser(string userId, string password)
        {
           
            try
            {
                string DomainName = "BELCANAD";
                int PortNumber = 389;
                //string userId = "gtiruveedhula";
                //string password = "p3rf3ctIT@1dsd23%";
                string path = string.Format(@"LDAP://{0}:{1}", DomainName, PortNumber);

                string username = string.Format(@"{0}@{1}", userId, DomainName);
                DirectoryEntry de = new DirectoryEntry(path, username, password, AuthenticationTypes.Secure);
                DirectorySearcher ds = new DirectorySearcher(de);
                SearchResult result = ds.FindOne();
                if (result == null)
                {
                    return 0;
                }
                return 1;
            }
            catch (Exception ex)
            {
                string errmsg = ex.Message;
                return 0;
            }
        }
    }
}